package JEU;

import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.imageio.ImageIO;

import Ecran.Bouton;
import Ecran.Image;
import Ecran.Repere;
import Ecran.RobotRepere;

public class Cardinal extends SushiGoRound{

	/********************************************/

	/* Constructeur de la classe Cardinal */

	/********************************************/
	/** Le jeu Cardinal pr�sente une caract�ristique particuli�re. Sous windows, sa taille est de 550*550,
	 * alors que sous Linux sa taille est de 600*600.
	 * Pour reconna�tre la fen�tre de jeu on dispose alors de deux images, coinJeu et coinJeu2 qui correspondent au coin
	 * inf�rieur gauche de la fen�tre de jeu pour la taille 600*600 et pour la taille 550*550
	 */
	private Image coinJeu2 ;


	public Cardinal(Robot r, Repere rep, int dim_x, int dim_y, String coinJeu, String coinJeu2)throws IOException, URISyntaxException {
		super(r, rep);
		robotrep = new RobotRepere(r, rep);		
		screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.coinJeu = Image.readIm(coinJeu);
		this.coinJeu2 = Image.readIm(coinJeu2);
		this.dim_jeu_x = dim_x;
		this.dim_jeu_y = dim_y;
		taille = 0;	

	}

	/********************************************/

	/* Méthodes de la classe Image */

	/********************************************/

	/**
	 * Ouvre la fenêtre du jeu Cardinal, et met la fenêtre de jeu au centre de la fenêtre du navigateur
	 */

	public void ouvreFenetre() throws IOException, URISyntaxException {
		Desktop.getDesktop()
		.browse(new URI("http://www.newgrounds.com/portal/view/634256"));
		this.robotrep.getRobot().delay(20000);
		

	}


	/**
	 * Fonction qui trouve la fen�tre de jeu dans l'�cran
	 */
	public boolean trouveFenetre() throws IOException, URISyntaxException {
		Image screenshot;
		int cpt = 0;
		int corner_px = -1;
		int corner_px2 = -1;
		do{
			System.out.println("Cherche la fenetre de jeu");
			screenshot = new Image(this.robotrep.getRobot().createScreenCapture(new Rectangle(screenSize)));
			// On cherche si on retrouvre l'image qui correspond au jeu 550*550
			corner_px = screenshot.trouveDansImage(coinJeu);
			// On cherche si on retrouve l'image qui correspond au jeu 600*600
			corner_px2 = screenshot.trouveDansImage(coinJeu2);
			cpt++;
			this.robotrep.getRobot().delay(DELAY_SCREENSHOT);
		}while (corner_px == -1 && corner_px2 == -1 && cpt < SEUIL_CHERCHE_JEU);

		if (cpt == SEUIL_CHERCHE_JEU) return false;
		else {
			// Si l'image est celle du jeu 600*600, on initialise les attributs avec les valeurs correspondantes.
			if (corner_px == -1) {
				System.out.println("version2");
				corner_px = corner_px2;
				this.coinJeu=this.coinJeu2;
			}
			int[] coin = Image.computeImageCorner(corner_px, coinJeu, screenshot,this.taille);
			this.robotrep.setRepere(new Repere(coin[0], coin[1]));
			this.robotrep.getRobot().mouseMove(this.robotrep.getRepere().getCoord_x(), this.robotrep.getRepere().getCoord_y());
			return true;
		}
	}

	public void joue() throws IOException{
		// On appelle la m�thode qui joue au jeu 600*600 o� 550*550 en fonction des modifications faites
		// par la m�thode trouve fen�tre
		if (this.coinJeu==this.coinJeu2) jouev1();
		else jouev2();
	}
	/**
	 * Fonction qui joue au jeu Cardinal 600*600
	 */

	public void jouev1() throws IOException{
		//System.out.println(this.robotrep.getRepere().getCoord_x()+" "+this.robotrep.getRepere().getCoord_y());
		this.robotrep.setRepere(new Repere (this.robotrep.getRepere().getCoord_x()-20, this.robotrep.getRepere().getCoord_y()-580));
		Bouton play = new Bouton(300,580,this.robotrep);
		play.clicGauche();
		this.robotrep.getRobot().delay(1500);
		//int a = 0;
		for (int i = 0 ; i < 100; i ++){
			BufferedImage im = this.robotrep.getRobot().createScreenCapture(new Rectangle(this.robotrep.getRepere().getCoord_x(),
					this.robotrep.getRepere().getCoord_y(), 600 ,600));
			/*ImageIO.write(im,"png", new File( "test"+i+".png"));*/
			//System.out.println(im.getRGB(270,90)+" "+im.getRGB(270,460)+" "+im.getRGB(90,270)+" "+im.getRGB(460,270));

			if (im.getRGB(270,90)!=-5242598){

				System.out.println("up");
				this.robotrep.getRobot().keyPress(KeyEvent.VK_UP);
				//this.robotrep.getRobot().delay(500);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_UP);


			}
			else if ( im.getRGB(270,500)!=-5242598){
				System.out.println("down");
				this.robotrep.getRobot().keyPress(KeyEvent.VK_DOWN);
				//this.robotrep.getRobot().delay(500);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_DOWN);

			}
			else if (im.getRGB(90,270)!=-5242598) {
				System.out.println("lfeft");
				this.robotrep.getRobot().keyPress(KeyEvent.VK_LEFT);
				//this.robotrep.getRobot().delay(500);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_LEFT);

			}
			else if (im.getRGB(500,270)!=-5242598 ){

				System.out.println("right");
				this.robotrep.getRobot().keyPress(KeyEvent.VK_RIGHT);
				//this.robotrep.getRobot().delay(500);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_RIGHT);

			}
			System.out.println(i);
			this.robotrep.getRobot().delay(490);
		}


	}
	/**
	 * M�thode qui joue au jeu Cardinal 550*550
	 * @throws IOException
	 */
	public void jouev2() throws IOException{
		//System.out.println(this.robotrep.getRepere().getCoord_x()+" "+this.robotrep.getRepere().getCoord_y());
		this.robotrep.setRepere(new Repere (this.robotrep.getRepere().getCoord_x(), this.robotrep.getRepere().getCoord_y()-530));
		Bouton play = new Bouton(270,522,this.robotrep);
		play.clicGauche();
		this.robotrep.getRobot().delay(1500);
		//int a = 0;
		for (int i = 0 ; i < 5000; i ++){
			BufferedImage im = this.robotrep.getRobot().createScreenCapture(new Rectangle(this.robotrep.getRepere().getCoord_x(),
					this.robotrep.getRepere().getCoord_y(), 550 ,550));
			/*ImageIO.write(im,"png", new File( "test"+i+".png"));*/

			if (im.getRGB(270,90)!=-5242598){

				this.robotrep.getRobot().keyPress(KeyEvent.VK_UP);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_UP);


			}
			else if ( im.getRGB(270,460)!=-5242598){
				this.robotrep.getRobot().keyPress(KeyEvent.VK_DOWN);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_DOWN);

			}
			else if (im.getRGB(90,270)!=-5242598) {
				this.robotrep.getRobot().keyPress(KeyEvent.VK_LEFT);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_LEFT);

			}
			else if (im.getRGB(460,270)!=-5242598 ){

				this.robotrep.getRobot().keyPress(KeyEvent.VK_RIGHT);
				this.robotrep.getRobot().keyRelease(KeyEvent.VK_RIGHT);

			}
			this.robotrep.getRobot().delay(490);
		}

	}

	


}