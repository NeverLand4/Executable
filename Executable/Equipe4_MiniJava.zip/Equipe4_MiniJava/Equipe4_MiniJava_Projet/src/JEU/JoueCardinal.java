package JEU;
import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Robot;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Scanner;

import Ecran.Repere;

public class JoueCardinal{
	static Scanner sc = new Scanner (System.in);
	public static void main (String [] args) throws IOException, URISyntaxException, AWTException{

		Cardinal jeu = new Cardinal(new Robot(), new Repere(0, 0),550,550, "Cardinal.png", "Cardinal2.png");
		try{
		jeu.ouvreFenetre();}
		catch (Exception e){
			System.out.println("Impossible d'ouvrir la fen�tre de jeu, merci d'ouvrir la fen�tre dans le navigateur.\n "
					+ "http://www.newgrounds.com/portal/view/634256/");
		}
		boolean fenetre = false;
		try{fenetre= jeu.trouveFenetre();}
		catch (Exception e){
				System.out.println("Impossible d'obtenir la taille de l'écran. \nEntrer la largeur de l'écran?");
				int width = sc.nextInt();
				System.out.println("Entrer la hauteur de l'écran ");
				int height = sc.nextInt();
				jeu.setScreensize(new Dimension (width, height));
				fenetre = jeu.trouveFenetre();
			}
		if (fenetre) jeu.joue();
		
	}
}