package JEU;

import java.awt.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Scanner;

import Ecran.Repere;
import Exception.JeuFiniException;

public class JoueColorFinger{
	
	public static Scanner sc = new Scanner (System.in);
	public static void main(String[] args) throws IOException, AWTException, URISyntaxException, JeuFiniException {

		ColorFinger jeu = new ColorFinger(new Robot(), new Repere(0, 0));		
		
		try{jeu.ouvreFenetre();}
			catch (Exception e){
				System.out.println("Impossible d'ouvrir la fen�tre de jeu, merci d'ouvrir la fen�tre dans le navigateur.\n "
						+ "http://www.newgrounds.com/portal/view/642967");
			}
		boolean fenetre =false;
		try {fenetre= jeu.trouveFenetre();}
		catch (Exception e){
				System.out.println("Impossible d'obtenir la taille de l'écran. \nEntrer la largeur de l'écran?");
				int width = sc.nextInt();
				System.out.println("Entrer la hauteur de l'écran ");
				int height = sc.nextInt();
				jeu.setScreensize(new Dimension (width, height));
				fenetre = jeu.trouveFenetre();
			}
		if (fenetre) {
			jeu.commenceJeu();
			jeu.joue();
		}
	}

}